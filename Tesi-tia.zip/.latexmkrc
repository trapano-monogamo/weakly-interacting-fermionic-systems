$pdf_mode = 1;
$pdflatex = 'pdflatex -interaction=nonstopmode';
$bibtex = 'bibtex';